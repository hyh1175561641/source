# How to contribue code to calc

## CONTRIB-CODE

See the file
<A HREF="https://github.com/lcn2/calc/blob/master/CONTRIB-CODE">CONTRIB-CODE</A>
for how to contribue code to calc.
